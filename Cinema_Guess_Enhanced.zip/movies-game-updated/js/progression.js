/* =========================================================================
   progression.js — Cinema Guess progression & meta-game layer
   Adds: Adaptive Difficulty, Intelligent Movie Selection, Dynamic Timer,
   XP/Level, Rank System, Combo Engine, Achievement Engine, Statistics
   Engine, Lucky Bonus Rounds, Daily Challenge, Endless Survival Mode,
   Power-Ups, Dynamic Backgrounds, richer win/lose feedback.

   This file is 100% additive. It never touches app.js's internal state
   directly — it only listens for the "cg:*" events app.js emits, and calls
   the small window.CGGame helper API app.js exposes for the handful of
   effects (extra life, free hint, freeze timer, bonus score) that need to
   reach back into the live round. If this script fails to load for any
   reason, the base game keeps working exactly as before.
   ========================================================================= */

(() => {
  "use strict";

  /* --------------------------- persisted storage -------------------------- */
  const KEYS = {
    xp: "cg_prog_xp",
    level: "cg_prog_level",
    stats: "cg_prog_stats",
    achievements: "cg_prog_achievements",
    recent: "cg_prog_recent_movies",
    dailyDate: "cg_prog_daily_date",
    dailyIds: "cg_prog_daily_ids",
    dailyDone: "cg_prog_daily_done",
    powerups: "cg_prog_powerups",
    endlessBest: "cg_prog_endless_best"
  };

  const store = {
    get(key, fallback) {
      try {
        const raw = localStorage.getItem(key);
        if (raw === null) return fallback;
        return JSON.parse(raw);
      } catch (e) { return fallback; }
    },
    set(key, value) {
      try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* ignore */ }
    }
  };

  const DEFAULT_STATS = {
    gamesPlayed: 0, moviesPlayed: 0, correct: 0, wrong: 0,
    hintsUsed: 0, skips: 0, totalGuessTime: 0, guessSamples: 0,
    fastestGuess: null, longestStreak: 0, highestCombo: 0
  };

  const state = {
    xp: store.get(KEYS.xp, 0),
    level: store.get(KEYS.level, 1),
    stats: Object.assign({}, DEFAULT_STATS, store.get(KEYS.stats, {})),
    achievements: store.get(KEYS.achievements, {}), // id -> true
    recent: store.get(KEYS.recent, []),              // recently-played movie ids
    powerups: store.get(KEYS.powerups, {}),           // id -> count
    dailyActive: false,
    dailyMovies: null,
    endlessActive: false,
    endlessLoops: 0,
    activeLuckyBonus: null,   // bonus type active for the current round
    lastRoundStartedAt: 0
  };

  /* --------------------------------- ranks --------------------------------- */
  const RANKS = [
    { name: "Beginner",        min: 1,  icon: "🎬" },
    { name: "Movie Fan",       min: 15, icon: "🍿" },
    { name: "Tollywood Lover", min: 29, icon: "❤️‍🔥" },
    { name: "Cinema Expert",   min: 43, icon: "🎥" },
    { name: "Movie Master",    min: 57, icon: "🏆" },
    { name: "Cinema Legend",   min: 71, icon: "🌟" },
    { name: "Tollywood King",  min: 86, icon: "👑" }
  ];
  const MAX_LEVEL = 100;

  function rankForLevel(level) {
    let current = RANKS[0];
    for (const r of RANKS) if (level >= r.min) current = r;
    return current;
  }
  function xpNeededForLevel(level) {
    // gently increasing curve, ~100 XP at level 1 growing to ~4000 near level 100
    return Math.round(100 + (level - 1) * 38);
  }

  /* ------------------------------- power-ups -------------------------------- */
  const POWERUPS = {
    freeze:   { icon: "🧊", label: "Freeze Timer" },
    life:     { icon: "❤️", label: "Extra Life" },
    hint:     { icon: "💡", label: "Free Hint" },
    skip:     { icon: "⏭️", label: "Free Skip" },
    doubler:  { icon: "✨", label: "Double Score" }
  };

  function grantPowerup(id, count) {
    state.powerups[id] = (state.powerups[id] || 0) + (count || 1);
    store.set(KEYS.powerups, state.powerups);
    renderPowerupBar();
  }
  function consumePowerup(id) {
    if (!state.powerups[id]) return false;
    state.powerups[id] -= 1;
    if (state.powerups[id] <= 0) delete state.powerups[id];
    store.set(KEYS.powerups, state.powerups);
    renderPowerupBar();
    return true;
  }

  /* -------------------------------- achievements ----------------------------- */
  const ACHIEVEMENTS = [
    { id: "first_win",      icon: "🥇", name: "First Win",       desc: "Answer your first movie correctly", check: s => s.correct >= 1 },
    { id: "correct_10",     icon: "🔟", name: "Getting Good",     desc: "10 correct answers", check: s => s.correct >= 10 },
    { id: "correct_25",     icon: "🎯", name: "Sharp Shooter",    desc: "25 correct answers", check: s => s.correct >= 25 },
    { id: "correct_50",     icon: "🏹", name: "Cinephile",        desc: "50 correct answers", check: s => s.correct >= 50 },
    { id: "correct_100",    icon: "💯", name: "Movie Encyclopedia", desc: "100 correct answers", check: s => s.correct >= 100 },
    { id: "perfect_acc",    icon: "🌟", name: "Perfect Accuracy", desc: "Finish a round of 5+ with 100% accuracy", check: (s, ctx) => ctx && ctx.perfectGame },
    { id: "fast_guess",     icon: "⚡", name: "Fast Guess",       desc: "Answer correctly in under 5 seconds", check: (s, ctx) => ctx && ctx.fastGuess },
    { id: "no_hint",        icon: "🧠", name: "No Hint Needed",   desc: "Win a game without using a single hint", check: (s, ctx) => ctx && ctx.noHintWin },
    { id: "combo_master",   icon: "🔥", name: "Combo Master",     desc: "Reach a 10-answer combo", check: (s, ctx) => ctx && ctx.streak >= 10 },
    { id: "movie_legend",   icon: "👑", name: "Movie Legend",     desc: "Reach Cinema Legend rank (level 71)", check: () => state.level >= 71 }
  ];

  function checkAchievements(ctx) {
    ACHIEVEMENTS.forEach(a => {
      if (state.achievements[a.id]) return;
      let unlocked = false;
      try { unlocked = !!a.check(state.stats, ctx || {}); } catch (e) { unlocked = false; }
      if (unlocked) {
        state.achievements[a.id] = true;
        store.set(KEYS.achievements, state.achievements);
        showAchievementToast(a);
        // Every achievement grants a random power-up as a reward.
        const ids = Object.keys(POWERUPS);
        grantPowerup(ids[Math.floor(Math.random() * ids.length)], 1);
      }
    });
  }

  /* ----------------------------------- XP ------------------------------------ */
  function gainXP(amount, reason) {
    if (amount <= 0) return;
    state.xp += amount;
    let leveledUp = false;
    while (state.level < MAX_LEVEL && state.xp >= xpNeededForLevel(state.level)) {
      state.xp -= xpNeededForLevel(state.level);
      state.level += 1;
      leveledUp = true;
    }
    if (state.level >= MAX_LEVEL) state.xp = 0;
    store.set(KEYS.xp, state.xp);
    store.set(KEYS.level, state.level);
    renderRankCard();
    if (leveledUp) {
      showAchievementToast({ icon: rankForLevel(state.level).icon, name: `Level ${state.level}!`, desc: rankForLevel(state.level).name }, true);
      checkAchievements({});
    }
    return { leveledUp };
  }

  /* --------------------------------- UI: toasts -------------------------------- */
  function showAchievementToast(item, isXp) {
    const layer = document.getElementById("achievement-popup-layer");
    if (!layer) return;
    const el = document.createElement("div");
    el.className = "achievement-toast" + (isXp ? " at-xp" : "");
    el.innerHTML = `<span class="at-icon">${item.icon}</span><span><span class="at-title">${item.name}</span><span class="at-sub">${item.desc}</span></span>`;
    layer.appendChild(el);
    requestAnimationFrame(() => el.classList.add("show"));
    setTimeout(() => {
      el.classList.remove("show");
      setTimeout(() => el.remove(), 400);
    }, 3200);
  }

  function showComboBanner(text) {
    const el = document.getElementById("combo-banner");
    if (!el) return;
    el.textContent = text;
    el.classList.remove("show");
    void el.offsetWidth;
    el.classList.add("show");
    clearTimeout(showComboBanner._t);
    showComboBanner._t = setTimeout(() => el.classList.remove("show"), 1000);
  }

  function showLuckyBanner(text) {
    const el = document.getElementById("lucky-banner");
    if (!el) return;
    el.textContent = text;
    el.classList.add("show");
    clearTimeout(showLuckyBanner._t);
    showLuckyBanner._t = setTimeout(() => el.classList.remove("show"), 2600);
  }

  /* --------------------------------- UI: rank card ------------------------------ */
  function renderRankCard() {
    const rank = rankForLevel(state.level);
    const needed = state.level >= MAX_LEVEL ? 1 : xpNeededForLevel(state.level);
    const pct = state.level >= MAX_LEVEL ? 100 : Math.min(100, Math.round((state.xp / needed) * 100));

    const badge = document.getElementById("rank-badge");
    const name = document.getElementById("rank-name");
    const lvl = document.getElementById("rank-level");
    const fill = document.getElementById("xp-fill");
    const caption = document.getElementById("xp-caption");
    if (badge) badge.textContent = rank.icon;
    if (name) name.textContent = rank.name;
    if (lvl) lvl.textContent = state.level >= MAX_LEVEL ? "MAX" : `Lv. ${state.level}`;
    if (fill) fill.style.width = pct + "%";
    if (caption) caption.textContent = state.level >= MAX_LEVEL ? "Max level reached!" : `${state.xp} / ${needed} XP`;
  }

  /* --------------------------------- UI: power-up bar ---------------------------- */
  function renderPowerupBar() {
    const bar = document.getElementById("powerup-bar");
    if (!bar) return;
    bar.innerHTML = "";
    Object.keys(state.powerups).forEach(id => {
      const count = state.powerups[id];
      if (!count) return;
      const meta = POWERUPS[id];
      if (!meta) return;
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "powerup-chip";
      chip.title = meta.label;
      chip.innerHTML = `<span>${meta.icon} ${meta.label}</span><span class="pu-count">${count}</span>`;
      chip.addEventListener("click", () => usePowerup(id));
      bar.appendChild(chip);
    });
  }

  function usePowerup(id) {
    if (!window.CGGame) return;
    const gs = window.CGGame.getState();
    if (gs.activeScreen !== "screen-game") { showAchievementToast({ icon: "ℹ️", name: "Start a game first", desc: "Power-ups only work mid-round" }); return; }
    if (!consumePowerup(id)) return;
    switch (id) {
      case "freeze": window.CGGame.freezeTimer(4000); break;
      case "life": window.CGGame.addLife(); break;
      case "hint": window.CGGame.freeHint(); break;
      case "skip": window.CGGame.skipFree(); break;
      case "doubler":
        state.pendingDoubler = true;
        window.CGGame.showToast("✨ Next correct answer scores double!");
        break;
    }
  }

  /* --------------------------------- UI: stats screen ---------------------------- */
  function renderStatsScreen() {
    const grid = document.getElementById("stats-grid");
    if (!grid) return;
    const s = state.stats;
    const accuracy = (s.correct + s.wrong) > 0 ? Math.round((s.correct / (s.correct + s.wrong)) * 100) : 0;
    const avgTime = s.guessSamples > 0 ? (s.totalGuessTime / s.guessSamples).toFixed(1) : "0.0";
    const rows = [
      ["Games Played", s.gamesPlayed],
      ["Movies Played", s.moviesPlayed],
      ["Correct", s.correct],
      ["Wrong", s.wrong],
      ["Accuracy", accuracy + "%"],
      ["Hints Used", s.hintsUsed],
      ["Skips", s.skips],
      ["Avg Guess Time", avgTime + "s"],
      ["Fastest Guess", s.fastestGuess !== null ? s.fastestGuess.toFixed(1) + "s" : "—"],
      ["Longest Streak", s.longestStreak],
      ["Highest Combo", s.highestCombo],
      ["Endless Best", store.get(KEYS.endlessBest, 0)]
    ];
    grid.innerHTML = rows.map(([label, value]) =>
      `<div class="stats-cell"><span class="sc-label">${label}</span><span class="sc-value">${value}</span></div>`
    ).join("");
  }

  function renderAchievementsScreen() {
    const grid = document.getElementById("achievements-grid");
    if (!grid) return;
    grid.innerHTML = ACHIEVEMENTS.map(a => {
      const unlocked = !!state.achievements[a.id];
      return `<div class="achv-card${unlocked ? " unlocked" : ""}">
        <span class="achv-icon">${a.icon}</span>
        <span class="achv-name">${a.name}</span>
        <span class="achv-desc">${unlocked ? a.desc : "Locked"}</span>
      </div>`;
    }).join("");
  }

  /* --------------------------- intelligent movie selection ------------------------ */
  function pushRecent(id) {
    state.recent = state.recent.filter(x => x !== id);
    state.recent.unshift(id);
    state.recent = state.recent.slice(0, 15);
    store.set(KEYS.recent, state.recent);
  }

  /* -------------------------------- daily challenge -------------------------------- */
  function todayKey() {
    const d = new Date();
    return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
  }
  function mulberry32(seed) {
    return function () {
      seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
      let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function hashStr(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) { h = (h * 31 + str.charCodeAt(i)) | 0; }
    return h;
  }
  function getDailyMovies() {
    const key = todayKey();
    const cachedDate = store.get(KEYS.dailyDate, null);
    const cachedIds = store.get(KEYS.dailyIds, null);
    if (cachedDate === key && Array.isArray(cachedIds) && cachedIds.length) {
      return cachedIds.map(id => MOVIES.find(m => m.id === id)).filter(Boolean);
    }
    const rand = mulberry32(hashStr(key));
    const idx = MOVIES.map((_, i) => i);
    for (let i = idx.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      [idx[i], idx[j]] = [idx[j], idx[i]];
    }
    const picked = idx.slice(0, 5).map(i => MOVIES[i]);
    store.set(KEYS.dailyDate, key);
    store.set(KEYS.dailyIds, picked.map(m => m.id));
    store.set(KEYS.dailyDone, false);
    return picked;
  }

  /* --------------------------------- dynamic backgrounds -------------------------- */
  function applyBodyBgClass(difficulty) {
    document.body.classList.remove("bg-difficulty-easy", "bg-difficulty-medium", "bg-difficulty-hard", "bg-victory", "bg-gameover", "bg-home");
    if (!difficulty) return;
    const map = { Easy: "bg-difficulty-easy", Medium: "bg-difficulty-medium", Hard: "bg-difficulty-hard" };
    if (map[difficulty]) document.body.classList.add(map[difficulty]);
  }
  let lastScreenSeen = "";
  setInterval(() => {
    const active = document.querySelector(".screen.active");
    if (!active || active.id === lastScreenSeen) return;
    lastScreenSeen = active.id;
    if (active.id === "screen-home" || active.id === "screen-howto" || active.id === "screen-settings" ||
      active.id === "screen-leaderboard" || active.id === "screen-stats" || active.id === "screen-achievements") {
      document.body.classList.remove("bg-victory", "bg-gameover", "bg-difficulty-easy", "bg-difficulty-medium", "bg-difficulty-hard");
      document.body.classList.add("bg-home");
    } else if (active.id === "screen-win") {
      document.body.classList.remove("bg-home", "bg-gameover");
      document.body.classList.add("bg-victory");
    } else if (active.id === "screen-gameover") {
      document.body.classList.remove("bg-home", "bg-victory");
      document.body.classList.add("bg-gameover");
    }
  }, 350);

  /* ------------------------------ adaptive difficulty / timer --------------------- */
  window.CGProgression = {
    getPool(allMovies, difficulty) {
      if (state.dailyActive && state.dailyMovies) return state.dailyMovies;
      if (state.endlessActive) return null; // defer to app.js's own difficulty filter
      // Intelligent selection: avoid recently-played movies when enough remain
      let base = difficulty === "All" ? allMovies : allMovies.filter(m => m.difficulty === difficulty);
      if (!base.length) base = allMovies;
      if (!state.recent.length) return null;
      const fresh = base.filter(m => !state.recent.includes(m.id));
      return fresh.length >= Math.min(6, base.length) ? fresh : null;
    },
    isEndless() { return state.endlessActive; },
    onEndlessLoop() {
      state.endlessLoops += 1;
      showLuckyBanner(`♾️ Survival loop ${state.endlessLoops + 1} — movies are getting tougher!`);
    },
    getRoundTimer(baseTimer, gameState) {
      let t = baseTimer;
      if (state.endlessActive) {
        t = Math.max(20, baseTimer - state.endlessLoops * 6 - Math.floor(gameState.streak / 3) * 2);
      } else {
        // Smart adaptive difficulty: reward long streaks with a tighter, higher-stakes timer
        t = Math.max(baseTimer - 20, baseTimer - Math.floor(gameState.streak / 3) * 3);
      }
      return t;
    }
  };

  /* ------------------------------------ event wiring ------------------------------- */
  function onGameStart(e) {
    state.stats.gamesPlayed += 1;
    state.currentGameHints = 0;
    state.currentGameCorrect = 0;
    state.currentGameWrong = 0;
    saveStats();
    if (state.dailyActive) showLuckyBanner("📅 Daily Challenge — 5 movies, make them count!");
    if (state.endlessActive) { state.endlessLoops = 0; showLuckyBanner("♾️ Endless Survival Mode — how long can you last?"); }
  }

  function onRoundStart(e) {
    state.lastRoundStartedAt = Date.now();
    state.activeLuckyBonus = null;
    applyBodyBgClass(e.detail.movie && e.detail.movie.difficulty);

    // Lucky Bonus Round: ~14% chance per round (skip on the very first round feel-out)
    if (Math.random() < 0.14) {
      const bonuses = [
        { id: "double", label: "💰 Lucky Round: Double Score!" },
        { id: "triple_xp", label: "✨ Lucky Round: Triple XP!" },
        { id: "life", label: "❤️ Lucky Round: Correct answer grants an extra life!" },
        { id: "hint", label: "💡 Lucky Round: Free hint granted!" },
        { id: "bonus", label: "🎁 Lucky Round: +25 bonus points on correct!" }
      ];
      const bonus = bonuses[Math.floor(Math.random() * bonuses.length)];
      state.activeLuckyBonus = bonus.id;
      showLuckyBanner(bonus.label);
      if (bonus.id === "hint" && window.CGGame) window.CGGame.freeHint();
    }
  }

  function onCorrect(e) {
    const { movie, streak, hintLevel, timeLeft, timerSeconds } = e.detail;
    const elapsed = Math.max(0, timerSeconds - timeLeft);

    // stats
    state.stats.correct += 1;
    state.stats.moviesPlayed += 1;
    state.stats.totalGuessTime += elapsed;
    state.stats.guessSamples += 1;
    if (state.stats.fastestGuess === null || elapsed < state.stats.fastestGuess) state.stats.fastestGuess = elapsed;
    state.stats.longestStreak = Math.max(state.stats.longestStreak, streak);
    state.stats.highestCombo = Math.max(state.stats.highestCombo, streak);
    state.currentGameCorrect = (state.currentGameCorrect || 0) + 1;
    saveStats();
    if (movie) pushRecent(movie.id);

    // combo engine
    const comboText = {
      2: "🔥 Combo x2!", 5: "🔥🔥 Combo x5!", 10: "⚡ SUPER COMBO!",
      15: "🌟 LEGEND COMBO!", 20: "👑 ULTRA COMBO!"
    }[streak];
    if (comboText) showComboBanner(comboText);

    // lucky bonus payout
    if (state.activeLuckyBonus === "double" && window.CGGame) window.CGGame.addScore(10);
    if (state.activeLuckyBonus === "life" && window.CGGame) window.CGGame.addLife();
    if (state.activeLuckyBonus === "bonus" && window.CGGame) window.CGGame.addScore(25);
    if (state.pendingDoubler && window.CGGame) { window.CGGame.addScore(10); state.pendingDoubler = false; }

    // XP
    let xp = 15;
    const fast = elapsed <= 5;
    if (elapsed <= 8) xp += 10;
    if (hintLevel === 0) xp += 10;
    if (streak > 0 && streak % 5 === 0) xp += 25;
    if (state.activeLuckyBonus === "triple_xp") xp *= 3;
    gainXP(xp, "correct");

    checkAchievements({ streak, fastGuess: fast });

    // richer positive feedback with the movie's context
    if (movie && window.CGGame) {
      const fact = (movie.storyHints && movie.storyHints[1]) || (movie.storyHints && movie.storyHints[0]) || "";
      window.CGGame.showToast(`${movie.hero} · ${movie.director} · ${movie.year}${fact ? " — " + fact : ""}`);
    }

    state.activeLuckyBonus = null;
  }

  function onWrong(e) {
    state.stats.wrong += 1;
    state.stats.moviesPlayed += 1;
    state.currentGameWrong = (state.currentGameWrong || 0) + 1;
    saveStats();
    if (window.CGGame) {
      const livesLeft = e.detail.lives;
      window.CGGame.showToast(livesLeft > 0
        ? `Not quite — check the spelling or try a hint. ${livesLeft} ${livesLeft === 1 ? "life" : "lives"} left.`
        : "That was your last life!");
    }
  }

  function onHint() {
    state.stats.hintsUsed += 1;
    state.currentGameHints = (state.currentGameHints || 0) + 1;
    saveStats();
  }

  function onSkip(e) {
    state.stats.skips += 1;
    state.stats.moviesPlayed += 1;
    saveStats();
    if (e.detail.movie) pushRecent(e.detail.movie.id);
  }

  function onTimeout(e) {
    state.stats.wrong += 1;
    state.stats.moviesPlayed += 1;
    saveStats();
    if (e.detail.movie) pushRecent(e.detail.movie.id);
  }

  function onGameEnd(e) {
    const { won, score, correctCount, wrongCount, bestStreakRun } = e.detail;
    const total = correctCount + wrongCount;
    const perfectGame = total >= 5 && wrongCount === 0;
    const noHintWin = won && (state.currentGameHints || 0) === 0;

    // bonus XP for finishing a run
    let bonusXp = Math.round(score * 0.5);
    if (won) bonusXp += 40;
    if (perfectGame) bonusXp += 60;
    const result = gainXP(Math.max(0, bonusXp), "game-end");

    checkAchievements({ perfectGame, noHintWin, streak: bestStreakRun });

    if (state.endlessActive) {
      const best = store.get(KEYS.endlessBest, 0);
      if (score > best) store.set(KEYS.endlessBest, score);
      state.endlessActive = false;
    }
    if (state.dailyActive) {
      store.set(KEYS.dailyDone, true);
      state.dailyActive = false;
      state.dailyMovies = null;
    }

    const xpEarnedEl1 = document.getElementById("go-xp");
    const xpEarnedEl2 = document.getElementById("win-xp");
    if (xpEarnedEl1) xpEarnedEl1.textContent = "+" + Math.max(0, bonusXp);
    if (xpEarnedEl2) xpEarnedEl2.textContent = "+" + Math.max(0, bonusXp);

    renderRankCard();
    renderPowerupBar();
  }

  function saveStats() { store.set(KEYS.stats, state.stats); }

  document.addEventListener("cg:gameStart", onGameStart);
  document.addEventListener("cg:roundStart", onRoundStart);
  document.addEventListener("cg:correct", onCorrect);
  document.addEventListener("cg:wrong", onWrong);
  document.addEventListener("cg:hint", onHint);
  document.addEventListener("cg:skip", onSkip);
  document.addEventListener("cg:timeout", onTimeout);
  document.addEventListener("cg:gameEnd", onGameEnd);

  /* ------------------------------------- nav wiring --------------------------------- */
  function showScreenExternal(id) {
    document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
    const target = document.getElementById(id);
    if (target) target.classList.add("active");
  }

  function wireNav() {
    const dailyBtn = document.getElementById("btn-daily");
    const endlessBtn = document.getElementById("btn-endless");
    const statsBtn = document.getElementById("btn-stats");
    const statsBack = document.getElementById("btn-stats-back");
    const achvBtn = document.getElementById("btn-achievements");
    const achvBack = document.getElementById("btn-achievements-back");

    if (dailyBtn) dailyBtn.addEventListener("click", () => {
      if (typeof MOVIES === "undefined") return;
      state.dailyActive = true;
      state.endlessActive = false;
      state.dailyMovies = getDailyMovies();
      if (window.CGGame) window.CGGame.startNewGame();
    });

    if (endlessBtn) endlessBtn.addEventListener("click", () => {
      state.endlessActive = true;
      state.dailyActive = false;
      state.dailyMovies = null;
      if (window.CGGame) window.CGGame.startNewGame();
    });

    if (statsBtn) statsBtn.addEventListener("click", () => { renderStatsScreen(); showScreenExternal("screen-stats"); });
    if (statsBack) statsBack.addEventListener("click", () => showScreenExternal("screen-home"));
    if (achvBtn) achvBtn.addEventListener("click", () => { renderAchievementsScreen(); showScreenExternal("screen-achievements"); });
    if (achvBack) achvBack.addEventListener("click", () => showScreenExternal("screen-home"));
  }

  /* ------------------------------------------ init ---------------------------------- */
  function init() {
    renderRankCard();
    renderPowerupBar();
    wireNav();
  }

  document.addEventListener("DOMContentLoaded", init);
})();
